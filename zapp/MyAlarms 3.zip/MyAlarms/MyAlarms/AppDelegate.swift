//
//  AppDelegate.swift
//  MyAlarms
//
//  Created by IOS on 05/04/21.
//  Copyright © 2021 IOS. All rights reserved.
//

import UIKit
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    let notificationCenter = UNUserNotificationCenter.current()
    let options: UNAuthorizationOptions = [.alert, .sound, .badge]
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        notificationCenter.requestAuthorization(options: options) {
            (didAllow, error) in
            if !didAllow {
                print("User has declined notifications")
            }
        }
        
        notificationCenter.getNotificationSettings { (settings) in
            if settings.authorizationStatus != .authorized {
                // Notifications not allowed
            }
        }
        
        notificationCenter.delegate = self
        
        return true
    }
    
    
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert, .badge, .sound])
    }
    
    func scheduleNotification(title: String, subtitle: String, body: String, date: Date, repeatCount: String, repeatMode: String, _ completion: @escaping (Error?) -> ()) {
        var calendar = Calendar.current
        calendar.timeZone = TimeZone(abbreviation: "UTC")!
        
        let _repeatCount = Int(repeatCount) ?? 0
        var components: Set<Calendar.Component> = [.day, .hour, .minute]
        if(repeatMode == "Month") {
            components = [.day, .hour, .minute]
        }
        else if(repeatMode == "Day") {
            components = [.hour, .minute]
        }
        else if(repeatMode == "Hour") {
            components = [.minute]
        }
        else if(repeatMode == "Minute") {
            components = [.second]
        }
        
        let comp2 = calendar.dateComponents(components, from: date)
        
        //        if(repeatMode == "Month") {
        //            comp2.month = _repeatCount
        //        }
        //        else if(repeatMode == "Week") {
        //            comp2.weekdayOrdinal = _repeatCount
        //        }
        //        else if(repeatMode == "Day") {
        ////            comp2.day = _repeatCount
        //        }
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: comp2, repeats: _repeatCount > 0)
        //        let _date = (date.toString(stringFormatter: "yyyy/MM/dd") + "00:00:00").toDate(stringFormatter: "yyyy/MM/ddHH:mm:ss")
        //
        //        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 50, repeats: _repeatCount > 0)
        
        let content = UNMutableNotificationContent()
        content.title = title
        content.subtitle = subtitle
        content.body = body
        content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "alarm-tune.mp3"))
        content.userInfo = ["repeatCount": repeatCount,
                            "repeatMode": repeatMode]
        
        let request = UNNotificationRequest(
            identifier: Date().ticks,
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: { error in
            completion(error)
        })
    }
    
    
    // MARK: UISceneSession Lifecycle
    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
}


//
//  ViewController.swift
//  MyAlarms
//
//  Created by IOS on 05/04/21.
//  Copyright © 2021 IOS. All rights reserved.
//

import UIKit

protocol AddAlarmVCDelegate {
    func alarmAdded()
}

class AddAlarmVC: UIViewController {

    //MARK: Properties
    @IBOutlet weak var tfTitle: UITextView!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var lblRepeat: UILabel!
    
    let appDelegate = UIApplication.shared.delegate as? AppDelegate
    
    var alertError: UIAlertController!
    
    var delegate: AddAlarmVCDelegate?
    
    var selectedCount = ""
    var selectedMode = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    //MARK: Actions
    @IBAction func btnChooseDateAction(_ sender: UIButton) {
        lblStartDate.showDatePicker(vc: self, stringDateFromat: "dd/MM/yyyy", dateMode: UIDatePicker.Mode.date)
    }
    
    @IBAction func btnChooseTimeAction(_ sender: UIButton) {
        lblTime.showDatePicker(vc: self, stringDateFromat: "hh:mm aa", dateMode: UIDatePicker.Mode.time)
    }
    
    @IBAction func btnChooseRepeatAction(_ sender: UIButton) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "RepeatTypeVC") as! RepeatTypeVC
        vc.delegate = self
        self.present(vc, animated: true) {
            
        }
    }
    
    @IBAction func btnAddAlarmAction(_ sender: UIButton) {
        if(lblTime.text == "- Choose Time -") {
            let alert = UIAlertController(title: "Alert", message: "Please choose time.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true) {
                
            }
        }
        else if(lblStartDate.text == "-Start Date -") {
            let alert = UIAlertController(title: "Alert", message: "Please choose start date.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true) {
                
            }
        }
        else {
            let date = (lblStartDate.text! + lblTime.text!).toDate(stringFormatter: "dd/MM/yyyyhh:mm aa")
            appDelegate?.scheduleNotification(title: "MyAlarms", subtitle: tfTitle.text!, body: "", date: date, repeatCount: selectedCount, repeatMode: selectedMode, { (error) in
                if(error != nil) {
                    DispatchQueue.main.async {
                        self.alertError = UIAlertController(title: "Alert", message: error.debugDescription, preferredStyle: UIAlertController.Style.alert)
                        self.alertError.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                        self.present(self.alertError, animated: true, completion: nil)
                    }
                }
                else {
                    if(self.delegate != nil) {
                        DispatchQueue.main.async {
                            self.dismiss(animated: true) {
                                self.delegate?.alarmAdded()
                            }
                        }
                    }
                }
            })
        }
    }
    
}


extension AddAlarmVC: RepeatTypeVCDelegate {
    func selectedRepeat(count: String, mode: String) {
        selectedCount = count
        selectedMode = mode
        lblRepeat.text = "Every " + count + " " + mode
    }
}

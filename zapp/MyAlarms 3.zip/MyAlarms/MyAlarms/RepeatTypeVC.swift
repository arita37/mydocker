//
//  ViewController.swift
//  MyAlarms
//
//  Created by IOS on 05/04/21.
//  Copyright © 2021 IOS. All rights reserved.
//

import UIKit

protocol RepeatTypeVCDelegate {
    func selectedRepeat(count: String, mode: String)
}

class RepeatTypeVC: UIViewController {

    //MARK: Properties
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var lblMode: UILabel!
    
    var delegate: RepeatTypeVCDelegate?
    
    var toolBar = UIToolbar()
    var picker  = UIPickerView()
    
    var titles = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for i in 0...31 {
            titles.append("\(i)")
        }
    }

    //MARK: Actions
    @IBAction func btnChooseCountAction(_ sender: UIButton) {
        picker = UIPickerView.init()
        picker.delegate = self
        picker.dataSource = self
        picker.backgroundColor = UIColor.white
        picker.setValue(UIColor.black, forKey: "textColor")
        picker.autoresizingMask = .flexibleWidth
        picker.contentMode = .center
        picker.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 350)
        self.view.addSubview(picker)
                
        toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
//        toolBar.barStyle = .blackTranslucent
        toolBar.items = [UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped))]
        self.view.addSubview(toolBar)
    }
    
    @IBAction func btnChooseModeAction(_ sender: UIButton) {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Minute", style: .default , handler:{ (UIAlertAction)in
            self.lblMode.text = "Minute"
        }))

        alert.addAction(UIAlertAction(title: "Hour", style: .default , handler:{ (UIAlertAction)in
            self.lblMode.text = "Hour"
        }))
        
        alert.addAction(UIAlertAction(title: "Day", style: .default , handler:{ (UIAlertAction)in
            self.lblMode.text = "Day"
        }))
        
//        alert.addAction(UIAlertAction(title: "Week", style: .default , handler:{ (UIAlertAction)in
//            self.lblMode.text = "Week"
//        }))

        alert.addAction(UIAlertAction(title: "Month", style: .default , handler:{ (UIAlertAction)in
            self.lblMode.text = "Month"
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel , handler:{ (UIAlertAction)in
            
        }))
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
    
    @IBAction func btnDoneAction(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if(self.delegate != nil) {
                self.delegate?.selectedRepeat(count: self.lblCount.text!, mode: self.lblMode.text!)
            }
        }
    }
    
    @objc func onDoneButtonTapped() {
        toolBar.removeFromSuperview()
        picker.removeFromSuperview()
    }
    
}


extension RepeatTypeVC: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
        
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return titles.count
    }
        
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return titles[row]
    }
        
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lblCount.text = titles[row]
    }
}

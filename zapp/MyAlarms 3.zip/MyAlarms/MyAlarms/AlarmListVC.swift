//
//  ViewController.swift
//  MyAlarms
//
//  Created by IOS on 05/04/21.
//  Copyright © 2021 IOS. All rights reserved.
//

import UIKit

struct Alarm {
    var id: String
    var start_from: String
    var time: String
    var name: String
    var repeat_count: String
    var repeat_type: String
    var notifications: [String]
}

class AlarmListVC: UIViewController {

    //MARK: Properties
    @IBOutlet weak var tableViewAlarms: UITableView!
    @IBOutlet weak var viewNoData: UIView!
    
//    var alarms = [AlarmModelClass]()
    var alarms = [UNNotificationRequest]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableViewAlarms.delegate = self
        tableViewAlarms.dataSource = self
        
        getAlarms()
    }

    func getAlarms() {
        UNUserNotificationCenter.current().getPendingNotificationRequests(completionHandler: { (notifs) in
            self.alarms = notifs
            DispatchQueue.main.async {
                self.tableViewAlarms.reloadData()
            }
        })
//        CoreDataCrudClient.shared.fetch { (_alarms) in
//            self.alarms = _alarms
//            DispatchQueue.main.async {
//                self.tableViewAlarms.reloadData()
//            }
//        }
    }
    
    //MARK: Actions
    @IBAction func btnAddAlarmAction(_ sender: UIButton) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddAlarmVC") as! AddAlarmVC
        vc.delegate = self
        self.present(vc, animated: true) {
            
        }
    }
    
}

//MARK: TableView class extension
extension AlarmListVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewNoData.isHidden = alarms.count > 0
        return alarms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AlarmCell
        cell.lblTitle.text = (alarms[indexPath.row].trigger as! UNCalendarNotificationTrigger).nextTriggerDate()!.toString(stringFormatter: "hh:mm aa") + " - " +
            alarms[indexPath.row].content.subtitle
        if((alarms[indexPath.row].trigger as! UNCalendarNotificationTrigger).repeats) {
            let s1 = "Start from: " + (alarms[indexPath.row].trigger as! UNCalendarNotificationTrigger).nextTriggerDate()!.toString(stringFormatter: "dd/MMM/yyyy")
            let s2 = "Repeat: Every " + "\(alarms[indexPath.row].content.userInfo["repeatCount"] ?? "") \("\(alarms[indexPath.row].content.userInfo["repeatMode"] ?? "")")"
            let s3 = "Next: " + (alarms[indexPath.row].trigger as! UNCalendarNotificationTrigger).nextTriggerDate()!.toString(stringFormatter: "dd/MMM/yyyy hh:mm aa - EEE")

            cell.lblSubTitle.text = s1 + "\n" + s2 + "\n" + s3

        }
        else {
            cell.lblSubTitle.text = "No repeat"
        }
        
//        cell.lblTitle.text = alarms[indexPath.row].time + " - " +
//            alarms[indexPath.row].name
//        if((Int(alarms[indexPath.row].repeat_count) ?? 0) > 0) {
//            let s1 = "Start from: " + alarms[indexPath.row].start_from
//            let s2 = "Repeat: Every " + "\(alarms[indexPath.row].repeat_count) \("\(alarms[indexPath.row].repeat_type)")"
//            cell.lblSubTitle.text = s1 + "\n" + s2 + "\n"
//        }
//        else {
//            cell.lblSubTitle.text = "No repeat"
//        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            let alert = UIAlertController(title: "Delete Alarm", message: "Are you sure you want to delete this alarm?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.destructive, handler: { (_alert) in
//                for identifier in self.alarms[indexPath.row].notifications {
                UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [self.alarms[indexPath.row].identifier])
//                }
//                CoreDataCrudClient.shared.delete(userWhereKey: "id", value: self.alarms[indexPath.row].id)
                self.getAlarms()
            }))
            alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true) {
                
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}

extension AlarmListVC: AddAlarmVCDelegate {
    func alarmAdded() {
        getAlarms()
        let alertSuccess = UIAlertController(title: "Alarm Added", message: "Alarm added successfully.", preferredStyle: UIAlertController.Style.alert)
        alertSuccess.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alertSuccess, animated: true) {
            
        }
    }
}

//MARK: TableView Cell
class AlarmCell: UITableViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubTitle: UILabel!
}


